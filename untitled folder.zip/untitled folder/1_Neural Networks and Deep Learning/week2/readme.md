

### Pieter Abbeel interview

[`Pieter Abbeel`](Pieter Abbeel), UC Berkeley

这个访谈很有意思，大神说最早喜欢足球，但是最后没成为career。在本科的时候选择engineer想做更多应用的事情，但是每个方向都很感兴趣。

1.40: why deep reinforcement take off？

3.10: what is the next?    pattern

7.20: 20 years work now, tell me how you know about AI this time?

9.00: You have a continue career of AI, so your advise for new?
> Make sure try things yourself, not just read things or just watch videos.
> 16 year boy won kaggle!




